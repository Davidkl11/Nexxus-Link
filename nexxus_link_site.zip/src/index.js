import React from "react";
import ReactDOM from "react-dom/client";
import NexxusLink from "./NexxusLink";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<NexxusLink />);