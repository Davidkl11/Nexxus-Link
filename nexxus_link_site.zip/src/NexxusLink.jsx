import React from "react";

export default function NexxusLink() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Nexxus Link</h1>
      <p>Helping college students get internships through real success stories.</p>

      <div style={{ marginTop: '2rem' }}>
        <h2>Search Internship Insights</h2>
        <input type="text" placeholder="Search by company or major..." style={{ width: '100%', padding: '0.5rem' }} />
        <button style={{ marginTop: '1rem', padding: '0.5rem 1rem' }}>Search</button>
      </div>

      <div style={{ marginTop: '2rem' }}>
        <h2>Share Your Internship Story</h2>
        <input type="file" />
        <button style={{ marginTop: '1rem', padding: '0.5rem 1rem' }}>Upload</button>
      </div>

      <div style={{ marginTop: '2rem' }}>
        <h2>Why Nexxus Link?</h2>
        <ul>
          <li>Real stories from successful interns</li>
          <li>Filter by industry or major</li>
          <li>Learn what actually works</li>
        </ul>
      </div>
    </div>
  );
}